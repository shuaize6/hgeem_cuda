from pathlib import Path
import csv, statistics as st
p=Path('/home/xu/projects/HGEMM-CUDA/build')
for prefix in ('v6','v6_final'):
    rows=[]
    for batch in range(3):
        f=p/f'{prefix}_bench_{batch}.csv'
        if not f.exists(): continue
        data=list(csv.DictReader(f.open())); rows+=data
        print(prefix,'batch',batch,{v:st.median(float(r['ms']) for r in data if r['kernel']==v) for v in ('v4','v5.2','v6','cuBLAS')})
        for base in ('v4','v5.2','cuBLAS'):
            ratios=[]
            for rnd in range(12):
                t={r['kernel']:float(r['ms']) for r in data if int(r['round'])==rnd}
                ratios.append(t[base]/t['v6'])
            print('paired',base+'/v6',st.median(ratios),min(ratios),max(ratios),'wins',sum(x>1 for x in ratios))
    if rows:
        for v in ('v4','v5.2','v6','cuBLAS'):
            a=[float(r['ms']) for r in rows if r['kernel']==v]; med=st.median(a)
            print('POOLED',v,med,min(a),max(a),2*1024**3/(med*1e9))
    for v in ('v5_2','v6','cublas'):
        f=p/f'{prefix}_profile_{v}.csv'
        if not f.exists(): continue
        d=list(csv.DictReader(f.open()))[-1]
        print(prefix,'PROFILE',v)
        for k,val in d.items():
            if any(s in k for s in ('Kernel Name','launch__registers_per_thread','launch__shared_mem_per_block_static',
                 'warps_active.avg.pct_of_peak','issue_active.avg.pct','sm__inst_executed_pipe_tensor.sum',
                 'smsp__inst_executed.sum','sm__pipe_tensor_cycles_active.avg.pct','dram__throughput.avg.pct',
                 'l1tex__throughput.avg.pct','sm__throughput.avg.pct')):
                print(k,val)
    f=p/f'{prefix}_telemetry.csv'
    if f.exists():
        telemetry=[next(csv.reader([s])) for s in f.read_text().splitlines() if s.startswith('2026/')]
        for i,label in ((3,'temperature_C'),(4,'power_W'),(5,'SM_MHz'),(6,'memory_MHz')):
            vals=[float(r[i].strip().split()[0]) for r in telemetry]
            print(prefix,label,min(vals),max(vals))
