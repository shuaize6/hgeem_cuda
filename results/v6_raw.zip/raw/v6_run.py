from pathlib import Path
import subprocess
import time
import sys

root=Path('/home/xu/projects/HGEMM-CUDA')
exe=str(root/'build/bench_hgemm')
prefix='v6_final' if '--final' in sys.argv else 'v6'
def run(args,name):
    with (root/'build'/(prefix+'_'+name)).open('x') as f:
        subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True,cwd=root)
for tool in ('memcheck','racecheck','synccheck'):
    run(['/usr/local/cuda-12.8/bin/compute-sanitizer','--tool',tool,'--error-exitcode','3',exe,'--test-v6'],tool+'.log')
run([exe,'1024','1024','1024'],'original.log')
run([exe,'1023','1025','1007'],'odd_original.log')
query=['nvidia-smi','--query-gpu=timestamp,name,driver_version,temperature.gpu,power.draw,clocks.sm,clocks.mem,utilization.gpu','--format=csv']
with (root/'build'/(prefix+'_telemetry.csv')).open('x') as log:
    for batch in range(3):
        with (root/f'build/{prefix}_bench_{batch}.csv').open('x') as f:
            proc=subprocess.Popen([exe,'--bench-v6'],stdout=f,cwd=root)
            while proc.poll() is None:
                log.write(f'batch={batch}\n'); log.flush()
                subprocess.run(query,stdout=log,check=True)
                time.sleep(0.25)
            assert proc.returncode==0
ncu='/usr/local/cuda-12.8/bin/ncu'
for v in ('v5_2','v6','cublas'):
    report=root/f'build/{prefix}_profile_{v}'
    run([ncu,'--launch-count','1','--section','LaunchStats','--section','Occupancy',
         '--section','SpeedOfLight','--section','SchedulerStats','--section','MemoryWorkloadAnalysis_Tables',
         '--metrics','sm__inst_executed_pipe_tensor.sum,smsp__inst_executed.sum',
         '-o',str(report),exe,'--profile',v],'profile_'+v+'.log')
    run([ncu,'--import',str(report)+'.ncu-rep','--page','raw','--csv'],'profile_'+v+'.csv')
run(['/usr/local/cuda-12.8/bin/cuobjdump','--dump-sass',exe],'sass.txt')
