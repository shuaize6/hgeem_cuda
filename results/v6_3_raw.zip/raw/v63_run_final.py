import subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parent.parent

def run(label,args):
    print('START',label,' '.join(args),flush=True)
    with (root/'build'/('v63_final_'+label+'.log')).open('w') as f:
        p=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
    print('END',label,'exit',p.returncode,flush=True)
    if p.returncode: raise SystemExit(p.returncode)

run('test_small',['./build/bench_hgemm','--test-v6-3'])
run('test_large',['./build/bench_hgemm','--test-large-v6-3'])
for tool in ['memcheck','racecheck','synccheck']:
    run(tool,['/usr/local/cuda-12.8/bin/compute-sanitizer','--tool',tool,'--error-exitcode','3','./build/bench_hgemm','--test-v6-3'])
run('table',['./build/bench_hgemm','1024','1024','1024'])
with (root/'build/v63_final_telemetry.csv').open('w') as f:
    monitor=subprocess.Popen(['nvidia-smi','--query-gpu=timestamp,temperature.gpu,clocks.sm,power.draw,utilization.gpu,memory.used','--format=csv','-lms','1000'],stdout=f,stderr=subprocess.STDOUT)
    try:
        for batch in range(3):
            print('START timing',batch,flush=True)
            with (root/f'build/v63_final_timing_{batch}.csv').open('w') as out, (root/f'build/v63_final_timing_{batch}_checks.log').open('w') as err:
                p=subprocess.run(['./build/bench_hgemm','--bench-sizes'],cwd=root,stdout=out,stderr=err)
            print('END timing',batch,'exit',p.returncode,flush=True)
            if p.returncode:raise SystemExit(p.returncode)
    finally:
        monitor.terminate()
        monitor.wait()
