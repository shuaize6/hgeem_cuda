import subprocess
from pathlib import Path
root=Path(__file__).resolve().parent.parent
for dim in [1024,4096]:
    for version in ['v6_2','v6_3','cublas']:
        label=f'v63_final_profile_{version}_{dim}'
        args=['/usr/local/cuda-12.8/bin/ncu','--launch-count','1',
              '--section','LaunchStats','--section','Occupancy','--section','SpeedOfLight',
              '--section','SchedulerStats','--section','WarpStateStats',
              '--section','MemoryWorkloadAnalysis_Tables','--section','SourceCounters',
              '--metrics','sm__inst_executed_pipe_tensor.sum,smsp__inst_executed.sum',
              '--export','build/'+label,'--csv','--log-file','build/'+label+'.csv',
              './build/bench_hgemm','--profile',version,str(dim),str(dim),str(dim)]
        print('START',label,flush=True)
        with (root/'build'/(label+'.log')).open('w') as f:
            f.write(' '.join(args)+'\n'); f.flush()
            p=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
        print('END',label,p.returncode,flush=True)
        if p.returncode:raise SystemExit(p.returncode)

for report in sorted((root/'build').glob('v63*_profile_*.ncu-rep')):
    dest=report.with_name(report.stem.replace('_profile_','_metrics_')+'.csv')
    with dest.open('w') as f:
        subprocess.run(['/usr/local/cuda-12.8/bin/ncu','--import',str(report),'--page','raw','--csv'],stdout=f,check=True)
