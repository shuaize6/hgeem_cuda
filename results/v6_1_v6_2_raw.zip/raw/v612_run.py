from pathlib import Path
import subprocess,time,sys,csv,statistics as st
p=Path('/home/xu/projects/HGEMM-CUDA'); phase=sys.argv[1]; prefix='v'+phase
exe=str(p/'build/bench_hgemm'); suffix='6-1' if phase=='61' else '6-2'
def run(args,name):
    with (p/'build'/(prefix+'_'+name)).open('x') as f:
        subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,cwd=p,check=True)
if phase=='62':
    for baseline in ('v6','v6-1'):
        run([exe,'--test-'+baseline],'recheck_'+baseline+'.log')
        run([exe,'--test-large-'+baseline],'recheck_large_'+baseline+'.log')
for tool in ('memcheck','racecheck','synccheck'):
    run(['/usr/local/cuda-12.8/bin/compute-sanitizer','--tool',tool,'--error-exitcode','3',exe,'--test-v'+suffix],tool+'.log')
run([exe,'1024','1024','1024'],'original.log')
with (p/'build'/(prefix+'_telemetry.csv')).open('x') as log:
    for batch in range(3):
        with (p/f'build/{prefix}_bench_{batch}.csv').open('x') as f:
            proc=subprocess.Popen([exe,'--bench-v'+suffix],stdout=f,cwd=p)
            while proc.poll() is None:
                log.write(f'batch={batch}\n'); log.flush()
                subprocess.run(['nvidia-smi','--query-gpu=timestamp,temperature.gpu,power.draw,clocks.sm,clocks.mem,utilization.gpu','--format=csv'],stdout=log,check=True)
                time.sleep(0.25)
            assert proc.returncode==0
ncu='/usr/local/cuda-12.8/bin/ncu'
for v in (('v6','v6_1','cublas') if phase=='61' else ('v6','v6_1','v6_2','cublas')):
    report=p/f'build/{prefix}_profile_{v}'
    run([ncu,'--launch-count','1','--section','LaunchStats','--section','Occupancy',
         '--section','SpeedOfLight','--section','SchedulerStats','--section','MemoryWorkloadAnalysis_Tables',
         '--section','SourceCounters','--metrics','sm__inst_executed_pipe_tensor.sum,smsp__inst_executed.sum',
         '-o',str(report),exe,'--profile',v],'profile_'+v+'.log')
    run([ncu,'--import',str(report)+'.ncu-rep','--page','raw','--csv'],'profile_'+v+'.csv')
run(['/usr/local/cuda-12.8/bin/cuobjdump','--dump-sass',exe],'sass.txt')
