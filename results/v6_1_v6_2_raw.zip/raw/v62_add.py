from pathlib import Path
p=Path('/home/xu/projects/HGEMM-CUDA')
s=(p/'kernels/hgemm_v6_1.cu').read_text().replace('hgemm_v6_1','hgemm_v6_2').replace('#include <cstddef>','#include <cstddef>\n#include <cstdint>')
helper='''// dst 由 shared 行跨度和 8-half 列偏移保证 16-byte 对齐。
// 完整且对齐的 Global 包使用 128-bit 搬运，其余逐元素加载/补零。
__device__ __forceinline__ void load8(
    half* dst, const half* base, int rows, int cols, int row, int col)
{
    const bool firstValid = row < rows && col < cols;
    const half* src = firstValid ? base + static_cast<size_t>(row) * cols + col : base;
    uint4 value;
    if (firstValid && col + 7 < cols &&
        (reinterpret_cast<uintptr_t>(src) & 15) == 0) {
        value = *reinterpret_cast<const uint4*>(src);
    } else {
        half* elements = reinterpret_cast<half*>(&value);
        #pragma unroll
        for (int i = 0; i < 8; ++i)
            elements[i] = (firstValid && col + i < cols)
                ? src[i] : __float2half_rn(0.0f);
    }
    *reinterpret_cast<uint4*>(dst) = value;
}

'''
s=s.replace('__global__ void hgemm_v6_2_kernel(',helper+'__global__ void hgemm_v6_2_kernel(')
start=s.index('        #pragma unroll\n        for (int index = tid; index < BM * BK;')
end=s.index('        // WMMA 是 warp collective',start)
s=s[:start]+'''        // A: 每行 4 个包，warp 覆盖 8 行；B: 每行 8 个包，warp 覆盖 4 行。
        // 两个逻辑 tile 各有 256 个包，256 threads 每线程各搬运一个。
        int ar = tid / (BK / 8);
        int ac = (tid % (BK / 8)) * 8;
        int br = tid / (BN / 8);
        int bc = (tid % (BN / 8)) * 8;
        load8(&storage.input.As[ar][ac], A, M, K, blockRow + ar, kb + ac);
        load8(&storage.input.Bs[br][bc], B, K, N, kb + br, blockCol + bc);

'''+s[end:]
(p/'kernels/hgemm_v6_2.cu').write_text(s)
f=p/'CMakeLists.txt'; f.write_text(f.read_text().replace('    kernels/hgemm_v6_1.cu','    kernels/hgemm_v6_1.cu\n    kernels/hgemm_v6_2.cu'))
f=p/'include/hgemm.cuh'; f.write_text(f.read_text()+'\nvoid launch_hgemm_v6_2(\n    const half* A, const half* B, half* C,\n    int M, int N, int K, cudaStream_t stream = 0\n);\n')
f=p/'benchmark/bench_hgemm.cu'; s=f.read_text()
s=s.replace('launch_hgemm_v6_1};','launch_hgemm_v6_1, launch_hgemm_v6_2};').replace('"v6", "v6.1"};','"v6", "v6.1", "v6.2"};')
s=s.replace('    half *da{}, *db{}, *dc{};', '    half *da{}, *db{}, *dc{};\n    half *allocation_a{}, *allocation_b{};\n    int input_offset;')
s=s.replace('Matrix(int M, int N, int K, int pattern)', 'Matrix(int M, int N, int K, int pattern, int offset = 0)')
s=s.replace('c(size_t(M) * N)\n', 'c(size_t(M) * N), input_offset(offset)\n')
s=s.replace('CUDA_CHECK(cudaMalloc(&da, a.size() * 2));', 'CUDA_CHECK(cudaMalloc(&allocation_a, (a.size() + offset) * sizeof(half)));\n        da = allocation_a + offset;')
s=s.replace('CUDA_CHECK(cudaMalloc(&db, b.size() * 2));', 'CUDA_CHECK(cudaMalloc(&allocation_b, (b.size() + offset) * sizeof(half)));\n        db = allocation_b + offset;')
s=s.replace('CUDA_CHECK(cudaFree(da));','CUDA_CHECK(cudaFree(allocation_a));').replace('CUDA_CHECK(cudaFree(db));','CUDA_CHECK(cudaFree(allocation_b));')
s=s.replace('<< ",max_abs=" << maxerr', '<< ",input_offset_half=" << input_offset << ",max_abs=" << maxerr')
needle='    auto launch = [&](int v) {'
s=s.replace(needle,'''    if (experiment == 2)
    {
        labels[0] = "v6"; labels[1] = "v6.1"; labels[2] = "v6.2";
        versions[0] = 4; versions[1] = 5; versions[2] = 6;
    }
'''+needle)
s=s.replace('    if (mode == "bench-v6-1")','    if (mode == "bench-v6-2")\n        return benchmark_v6(2);\n    if (mode == "bench-v6-1")')
s=s.replace('    const int selected_test = ', '    const int selected_test = (mode == "test-v6-2" || mode == "test-large-v6-2") ? 6\n                            : ')
s=s.replace('        bool ok = true;','        if (mode == "test-v6-2")\n            shapes.insert(shapes.end(), {{65, 72, 40}, {63, 64, 8}, {65, 72, 24}});\n        bool ok = true;')
s=s.replace('                Matrix x(s[0], s[1], s[2], p);\n                for (int v = selected_test >= 0 ? selected_test : 0;\n                     v < (selected_test >= 0 ? selected_test + 1 : int(sizeof(launches) / sizeof(Launch))); ++v)\n                    ok = x.check(v, p) && ok;', '''                const int offsets = mode == "test-v6-2" ? 2 : 1;
                for (int offset = 0; offset < offsets; ++offset)
                {
                    Matrix x(s[0], s[1], s[2], p, offset);
                    for (int v = selected_test >= 0 ? selected_test : 0;
                         v < (selected_test >= 0 ? selected_test + 1 : int(sizeof(launches) / sizeof(Launch))); ++v)
                        ok = x.check(v, p) && ok;
                }''')
s=s.replace('version == "v6_1" ? 5 : -1','version == "v6_1" ? 5 : version == "v6_2" ? 6 : -1')
s=s.replace('v6_1 or cublas.','v6_1, v6_2 or cublas.').replace('v6/v6_1/cublas','v6/v6_1/v6_2/cublas')
s=s.replace('--bench-v6-1 | --test-v6[-1] | --test-large-v6[-1]', '--bench-v6-1 | --bench-v6-2 | --test-v6[-1/-2] | --test-large-v6[-1/-2]')
head,main=s.split('int main(int argc, char **argv)',1)
lines=main.splitlines(keepends=True); out=[]; i=0
while i<len(lines):
    line=lines[i]
    if 'float v6_1_ms = benchmark' in line:
        chunk=line+lines[i+1]; out.extend([chunk,chunk.replace('v6_1','v6_2')]); i+=2; continue
    if '!pass_v6_1)' in line:
        out.append(line.replace('!pass_v6_1)', '!pass_v6_1 || !pass_v6_2)')); i+=1; continue
    out.append(line)
    if 'v6_1' in line and 'Speedup' not in line:
        out.append(line.replace('v6_1','v6_2').replace('v6.1 pad','v6.2 vector'))
    i+=1
f.write_text(head+'int main(int argc, char **argv)'+''.join(out))
