from pathlib import Path
import csv,statistics as st
p=Path('/home/xu/projects/HGEMM-CUDA/build')
for phase in ('61','62'):
    allrows=[]
    for batch in range(3):
        f=p/f'v{phase}_bench_{batch}.csv'
        if not f.exists(): continue
        rows=list(csv.DictReader(f.open())); allrows+=rows
        names=list(dict.fromkeys(r['kernel'] for r in rows))
        print(phase,'batch',batch,{v:st.median(float(r['ms']) for r in rows if r['kernel']==v) for v in names})
        target='v6.1' if phase=='61' else 'v6.2'
        for base in names:
            if base==target: continue
            ratios=[]
            for rnd in range(12):
                t={r['kernel']:float(r['ms']) for r in rows if int(r['round'])==rnd}
                ratios.append(t[base]/t[target])
            print('paired',base+'/'+target,st.median(ratios),min(ratios),max(ratios),'wins',sum(x>1 for x in ratios))
    if allrows:
        for v in names:
            a=[float(r['ms']) for r in allrows if r['kernel']==v]; med=st.median(a)
            print('POOLED',v,med,min(a),max(a),'TFLOPS',2*1024**3/(med*1e9))
    for f in p.glob(f'v{phase}_profile_*.csv'):
        data=list(csv.DictReader(f.open()))
        if len(data)<2: continue
        print('PROFILE',f.name)
        for k,v in data[-1].items():
            if any(s in k for s in ('launch__registers_per_thread','launch__shared_mem_per_block_static',
                 'warps_active.avg.pct_of_peak','issue_active.avg.pct','sm__inst_executed_pipe_tensor.sum',
                 'smsp__inst_executed.sum','sm__pipe_tensor_cycles_active.avg.pct',
                 'sass_inst_executed_op_global_ld.sum','sass_inst_executed_op_shared_st.sum',
                 'data_bank_conflicts_pipe_lsu_mem_shared_op_ld.sum','data_pipe_lsu_wavefronts_mem_shared_op_ld.sum',
                 'wavefronts_shared_excessive','sass_inst_executed_op_local')):
                print(k,v)
    f=p/f'v{phase}_telemetry.csv'
    if f.exists():
        rows=[next(csv.reader([s])) for s in f.read_text().splitlines() if s.startswith('2026/')]
        for i,label in ((1,'temperature_C'),(2,'power_W'),(3,'SM_MHz')):
            vals=[float(r[i].strip().split()[0]) for r in rows]; print(label,min(vals),max(vals))
