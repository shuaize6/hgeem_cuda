from pathlib import Path
p=Path('/home/xu/projects/HGEMM-CUDA')
s=(p/'kernels/hgemm_v6.cu').read_text().replace('hgemm_v6','hgemm_v6_1')
s=s.replace('constexpr int THREADS = 256;', 'constexpr int THREADS = 256;\n// 每行增加 16 half，改变 bank 映射并保持 WMMA 的 32-byte 对齐。\nconstexpr int AS = BK + 16;\nconstexpr int BS = BN + 16;')
s=s.replace('half As[BM][BK];','half As[BM][AS];').replace('half Bs[BK][BN];','half Bs[BK][BS];')
s=s.replace('&storage.input.Bs[k][warpCol], BN)', '&storage.input.Bs[k][warpCol], BS)').replace('&storage.input.As[warpRow + i * 16][k], BK)', '&storage.input.As[warpRow + i * 16][k], AS)')
(p/'kernels/hgemm_v6_1.cu').write_text(s)
f=p/'CMakeLists.txt'; f.write_text(f.read_text().replace('    kernels/hgemm_v6.cu','    kernels/hgemm_v6.cu\n    kernels/hgemm_v6_1.cu'))
f=p/'include/hgemm.cuh'; f.write_text(f.read_text()+'\nvoid launch_hgemm_v6_1(\n    const half* A, const half* B, half* C,\n    int M, int N, int K, cudaStream_t stream = 0\n);\n')
f=p/'benchmark/bench_hgemm.cu'; s=f.read_text()
s=s.replace('launch_hgemm_v6};','launch_hgemm_v6, launch_hgemm_v6_1};').replace('"v5.2", "v6"};','"v5.2", "v6", "v6.1"};')
s=s.replace('int benchmark_v6()', 'int benchmark_v6(int experiment = 0)')
s=s.replace('    const char *labels[] = {"v4", "v5.2", "v6", "cuBLAS"};\n    const int versions[] = {0, 3, 4};','    const char *labels[] = {"v4", "v5.2", "v6", "cuBLAS"};\n    int versions[] = {0, 3, 4};\n    if (experiment == 1)\n    {\n        labels[0] = "v6"; labels[1] = "v6.1"; labels[2] = "v5.2";\n        versions[0] = 4; versions[1] = 5; versions[2] = 3;\n    }')
s=s.replace('    if (mode == "bench-v6")', '    if (mode == "bench-v6-1")\n        return benchmark_v6(1);\n    if (mode == "bench-v6")')
s=s.replace('    if (mode == "test" || mode == "test-large" || mode == "test-v6" || mode == "test-large-v6")','    const int selected_test = (mode == "test-v6-1" || mode == "test-large-v6-1") ? 5\n                            : (mode == "test-v6" || mode == "test-large-v6") ? 4 : -1;\n    if (mode == "test" || mode == "test-large" || selected_test >= 0)')
s=s.replace('(mode == "test-large" || mode == "test-large-v6")','(mode.rfind("test-large", 0) == 0)')
s=s.replace('for (int v = (mode == "test-v6" || mode == "test-large-v6") ? 4 : 0; v < 5; ++v)', 'for (int v = selected_test >= 0 ? selected_test : 0;\n                     v < (selected_test >= 0 ? selected_test + 1 : int(sizeof(launches) / sizeof(Launch))); ++v)')
s=s.replace('version == "v6" ? 4 : -1','version == "v6" ? 4 : version == "v6_1" ? 5 : -1')
s=s.replace('v6 or cublas.', 'v6, v6_1 or cublas.').replace('v5_2/v6/cublas', 'v5_2/v6/v6_1/cublas')
s=s.replace('--bench-v6 | --test-v6 | --test-large-v6 | ', '--bench-v6 | --bench-v6-1 | --test-v6[-1] | --test-large-v6[-1] | ')
head,main=s.split('int main(int argc, char **argv)',1)
lines=main.splitlines(keepends=True); out=[]; i=0
while i<len(lines):
    line=lines[i]
    if 'float v6_ms = benchmark' in line:
        chunk=line+lines[i+1]; out.extend([chunk,chunk.replace('v6','v6_1')]); i+=2; continue
    if '!pass_v6)' in line:
        out.append(line.replace('!pass_v6)', '!pass_v6 || !pass_v6_1)')); i+=1; continue
    out.append(line)
    if 'v6' in line and 'Speedup' not in line:
        out.append(line.replace('v6','v6_1').replace('v6_1 WMMA','v6.1 pad'))
    i+=1
f.write_text(head+'int main(int argc, char **argv)'+''.join(out))
