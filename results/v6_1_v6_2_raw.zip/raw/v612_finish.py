from pathlib import Path
import subprocess,zipfile
p=Path('/home/xu/projects/HGEMM-CUDA')
for f in (p/'kernels').glob('hgemm_v*.cu'):
    if f.name in ('hgemm_v6_1.cu','hgemm_v6_2.cu'): continue
    old=subprocess.check_output(['git','show','HEAD:'+str(f.relative_to(p))],cwd=p)
    assert old==f.read_bytes(),f
print('All existing kernel baselines unchanged')
sass=(p/'build/v62_sass.txt').read_text()
part=next(x for x in sass.split('Function : ') if 'hgemm_v6_2_kernel' in x.splitlines()[0])
assert 'LDG.E.128' in part and 'STS.128' in part
print('SASS 128-bit load/store verified')
with (p/'build/v612_diff.txt').open('wb') as f:
    subprocess.run(['git','diff'],cwd=p,stdout=f,check=True)
with (p/'build/v612_environment.txt').open('wb') as f:
    for cmd in (['nvidia-smi'],['/usr/local/cuda-12.8/bin/nvcc','--version'],['cmake','--version'],['g++','--version'],['git','rev-parse','HEAD']):
        subprocess.run(cmd,cwd=p,stdout=f,check=True)
files=sorted(f for f in (p/'build').glob('v6[12]*') if f.is_file())
archive=p/'results/v6_1_v6_2_raw.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for f in files: z.write(f,'raw/'+f.name)
    for rel in ('kernels/hgemm_v6_1.cu','kernels/hgemm_v6_2.cu','benchmark/bench_hgemm.cu','include/hgemm.cuh','CMakeLists.txt','README.md'):
        z.write(p/rel,'source/'+rel)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for f in files: assert z.read('raw/'+f.name)==f.read_bytes()
for f in files: f.unlink()
print('Verified combined archive and removed staging files')
